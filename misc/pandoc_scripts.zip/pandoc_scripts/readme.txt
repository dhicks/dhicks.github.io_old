These [TextWrangler](http://www.barebones.com/products/textwrangler/) Applescripts use [John MacFarlane's pandoc utility](http://johnmacfarlane.net/pandoc/) to convert among [markdown](http://daringfireball.net/projects/markdown/), HTML, and [LaTeX](http://www.tug.org/texlive/), and from any of these into RTF.  Since TextWrangler and Applescript are Mac-only, these scripts are also Mac-only.  

To use:  

1. Install [pandoc](http://johnmacfarlane.net/pandoc/). 
2. In TextWrangler, go to Scripts (the scroll icon) -> Open Scripts Folder, and drag the script files into the Finder window that opens. 
3. Write something in TextWrangler using markdown, HTML, or LaTeX. 
4. In the Scripts menu, select the appropriate *source -> target* script.  

* Pandoc needs to work with a file.  If your written something isn't saved, you'll be prompted to do so.  
* The target file will be in the same folder as the source file.  It will have the same name as the target, but the corresponding extension.  
* If the script detects a file with that name, it will ask you to confirm the overwrite.  
* TextWrangler will automatically open the result.  